#Importar os pacotes
library("rio") #Pacote para a manipulação do .csv
library("rpart")
library("rpart.plot")
library("pacman") # Pacote para a manipulação dos pacotes

#Abrir o arquivo json em um dataframe
fiocruz <- import("/home/renan/Desenvolvimento/R/fiocruzReduzido.csv")

delete <- c("V1",
            "author.ordemAutoria",
            "author.citationName_1",
            "author.citationName_2",
            "author.citationName_3",
            "author.citationName_4",
            "author.citationName_5",
            "author.identifierLattes",
            "author.researchArea_1",
            "author.researchArea_2",
            "author.researchArea_3",
            "author.researchArea_4",
            "author.researchArea_5",
            "author.miniBiography",
            "author.miniBiography_eng",
            "author.identifierOrcid")

fiocruz <- fiocruz[, !(names(fiocruz) %in% delete)]

rm(delete)

fiocruz$keyword <- as.numeric(as.factor(fiocruz$keyword))
fiocruz$author.name <- as.numeric(as.factor(fiocruz$author.name))
fiocruz$author.nationality <- as.numeric(as.factor(fiocruz$author.nationality))
fiocruz$author.birthCity <- as.numeric(as.factor(fiocruz$author.birthCity))
fiocruz$author.birthState <- as.factor(fiocruz$author.birthState)
fiocruz$author.birthCountry <- as.numeric(as.factor(fiocruz$author.birthCountry))

str(fiocruz)


#Embaralhar o dataframe
set.seed(9850)
g <- runif(nrow(fiocruz))
fiocruz_random <- fiocruz[order(g),]

modelo1 <- rpart(author.birthState ~ ., data=fiocruz_random[1:1000000,], method="class")

rpart.plot(modelo1)
rpart.plot(modelo1, type=3, extra=101, fallen.leaves=T)

predicao1 <- predict(modelo1, fiocruz_random[1000001:1388611,], type="class")

table(fiocruz_random[1000001:1388611,5], predicted = predicao1)

#Limprar os pacotes
p_unload(all) #Limpa todos os pacotes add-ons (necessita do pacman)

#Lipar o Ambiente (Environment)
rm(list=ls())

#Limpar o console
cat("\014") #Ou Ctrl+L
