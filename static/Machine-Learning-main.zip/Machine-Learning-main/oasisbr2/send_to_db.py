from sqlalchemy import create_engine
import pandas as pd
import psycopg2
import json
import os

files = os.listdir()
jsons = [file for file in files if not os.path.isdir(file) and '.json' in file]

db_config = {
    'host': '127.0.0.1',
    'database': 'postgres',
    'user': 'postgres',
    'password': '1234567890'
}

conn = psycopg2.connect(**db_config)

engine = create_engine(f"postgresql://{db_config['user']}:{db_config['password']}@{db_config['host']}/{db_config['database']}")

list_columns = []

for json in jsons:
    temp_df = pd.read_json(json)
    json_list = temp_df['response']['docs']
    df = pd.DataFrame(json_list)
    
    list_columns = list_columns + df.columns.tolist()
    
    del temp_df, json_list, df
    
list_set = set(list_columns)

list_columns = list(list_set)
    
def_columns = ', '.join([f'"{column}" text' for column in list_columns])

try:
    cursor = conn.cursor()
    query = f"CREATE TABLE IF NOT EXISTS oasisbr2 ({def_columns});"
    cursor.execute(query)
    conn.commit()

    print("Tabela criada com sucesso!")
    
except Exception as e:
    conn.rollback()
    print(f"Erro ao criar a tabela: {e}")
    
finally:
    cursor.close()
    conn.close()

for json in jsons:
    temp_df = pd.read_json(json)
    json_list = temp_df['response']['docs']
    df = pd.DataFrame(json_list)
    
    df.to_sql("oasisbr2", engine, if_exists='append', index=False)
    
    del temp_df, json_list, df
    
    print(f"{json} enviado ao banco com sucesso!")
