import psycopg2
import json
import os

conn = psycopg2.connect(
       database="postgres",
       user="postgres",
       password="1234567890",
       host="127.0.0.1",
       port="5432")

cursor = conn.cursor()

# Diretório onde estão os arquivos JSON
diretorio = 'output/'

# Iterar sobre os arquivos no diretório
for arquivo_json in os.listdir(diretorio):
    if arquivo_json.endswith('.json'):
        with open(os.path.join(diretorio, arquivo_json), 'r') as arquivo:
            data = json.load(arquivo)

            # Extrair nomes das colunas do JSON
            colunas = data.keys()

            # Montar a query para criar a tabela
            create_table_query = f"CREATE TABLE IF NOT EXISTS oasisbr2 ({', '.join([f'{coluna} text' for coluna in colunas])});"

            # Criar a tabela
            cursor.execute(create_table_query)
            conn.commit()

# Fechar a conexão
cursor.close()
conn.close()
