import os
import subprocess

# Crie uma nova pasta para armazenar os arquivos de saída
if not os.path.exists('output'):
    os.mkdir('output')

# Lista todos os arquivos na pasta atual
files = os.listdir()

# Filtra apenas os arquivos que não são pastas e não têm extensão
input_files = [file for file in files if not os.path.isdir(file) and '.' not in file]

# Executa o comando para cada arquivo de entrada
for input_file in input_files:
    output_file = os.path.splitext(input_file)[0] + '.json'
    output_file = os.path.join('output', output_file)
    
    # Comando para executar a formatação JSON
    command = f'python3 -m json.tool {input_file} > {output_file}'
    
    # Executa o comando no terminal
    subprocess.run(command, shell=True)
    
    print(f'Arquivo "{output_file}" criado com sucesso!')

print("Formatação JSON concluída!")
