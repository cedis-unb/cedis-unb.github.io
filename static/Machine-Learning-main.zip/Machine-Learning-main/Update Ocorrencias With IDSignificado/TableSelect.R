library(janitor)
library(stringr)
library(stringi)

StrReplace = c(
  "/"="",
  "\'"="",
  "\""="",
  "c\\("="",
  "C\\("="",
  "\\("="",
  "\\)"="",
  "\\\\"="",
  "\\:"="",
  "~"="",
  ";"="",
  "\\^"="",
  "="="",
  ">"="",
  "<"="",
  "º"="o",
  "ª"="a",
  "±"="",
  "-"="",
  ""="",
  "_"="",
  "\\+"="",
  "\\."="",
  "\\,"=""
)

StrQuery <-paste0("SELECT \"id\", \"Token\", ROW_NUMBER () OVER (ORDER BY \"id\") FROM \"Ocorrencias\" WHERE \"Tipo\"=1 AND \"id\" > 34320619 ORDER BY \"id\"")
ocorrencias <- le_dados(StrQuery)
desconectar_db()
gc()

ocorrencias$Token <- str_replace_all(ocorrencias$Token,"[^[:graph:]]", " ")
gc()

ocorrencias$Token <- str_replace(ocorrencias$Token, "^([0123456789])", "n\\1")
gc()

ocorrencias$Token <- str_replace_all(ocorrencias$Token,StrReplace)
gc()

ocorrencias$Token <- tolower(ocorrencias$Token)
gc()

ocorrencias$Token <- rm_accent(ocorrencias$Token)
gc()

StrQuery <-paste0("SELECT \"IDSignificado\", \"Palavra\" FROM \"Dicionario\"")
dicionario <- le_dados(StrQuery)
desconectar_db()
gc()

dicionario$Palavra <- tolower(dicionario$Palavra)
dicionario$Palavra <- rm_accent(dicionario$Palavra)
gc()

id <- ocorrencias[, 1]
idsignificado <- dicionario[, 1]
token <- ocorrencias[, 2]
palavra <- dicionario[, 2]

comp <- token %in% palavra
gc()
