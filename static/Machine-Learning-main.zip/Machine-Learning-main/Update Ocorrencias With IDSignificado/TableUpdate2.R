library(janitor)
library(stringr)
library(stringi)

library(RPostgres)

le_dados = function(strQuery) {
  db <- 'oasisbr2'
  host_db <- 'localhost'
  db_port <- '5432'
  db_user <- 'postgres'
  db_password <- 'SENHA'
  con <-
    dbConnect(
      RPostgres::Postgres(),
      dbname = db,
      host = host_db,
      port = db_port,
      user = db_user,
      password = db_password
    )
  dados <- dbGetQuery(con, strQuery)
  
  # VERIFICAR NECESSIDADE
  dados <- replace(x = dados,
                   list = is.na(dados),
                   values = 0)
  
  rm(con, db, db_password, db_port, db_user, host_db, strQuery)
  return(dados)
}


escreve_dados = function(strQuery) {
  db <- 'oasisbr2'  #provide the name of your db
  host_db <- 'localhost'
  db_port <- '5432'  # or any other port specified by the DBA
  db_user <- 'postgres'
  db_password <- 'SENHA'
  con <-
    dbConnect(
      RPostgres::Postgres(),
      dbname = db,
      host = host_db,
      port = db_port,
      user = db_user,
      password = db_password
    )
  dados <- dbExecute(con, strQuery)
  
  rm(con, db, db_password, db_port, db_user, host_db, strQuery)
}

desconectar_db = function() {
  db <- 'oasisbr2'
  host_db <- 'localhost'
  db_port <- '5432'
  db_user <- 'postgres'
  db_password <- 'SENHA'
  con <-
    dbConnect(
      RPostgres::Postgres(),
      dbname = db,
      host = host_db,
      port = db_port,
      user = db_user,
      password = db_password
    )
  
  dbDisconnect(con)
  rm(con, db, db_password, db_port, db_user, host_db)
}

rm_accent <- function(str,pattern="all") {
  if(!is.character(str))
    str <- as.character(str)
  pattern <- unique(pattern)
  if(any(pattern=="Ç"))
    pattern[pattern=="Ç"] <- "ç"
  symbols <- c(
    acute = "áéíóúÁÉÍÓÚýÝ",
    grave = "àèìòùÀÈÌÒÙ",
    circunflex = "âêîôûÂÊÎÔÛ",
    tilde = "ãõÃÕñÑ",
    umlaut = "äëïöüÄËÏÖÜÿ",
    cedil = "çÇ"
  )
  nudeSymbols <- c(
    acute = "aeiouAEIOUyY",
    grave = "aeiouAEIOU",
    circunflex = "aeiouAEIOU",
    tilde = "aoAOnN",
    umlaut = "aeiouAEIOUy",
    cedil = "cC"
  )
  accentTypes <- c("Ž","`","^","~","š","ç")
  if(any(c("all","al","a","todos","t","to","tod","todo")%in%pattern)) # opcao retirar todos
    return(chartr(paste(symbols, collapse=""), paste(nudeSymbols, collapse=""), str))
  for(i in which(accentTypes%in%pattern))
    str <- chartr(symbols[i],nudeSymbols[i], str)
  return(str)
}

StrReplace = c(
  "/"="",
  "\'"="",
  "\""="",
  "c\\("="",
  "C\\("="",
  "\\("="",
  "\\)"="",
  "\\\\"="",
  "\\:"="",
  "~"="",
  ";"="",
  "\\^"="",
  "="="",
  ">"="",
  "<"="",
  "º"="o",
  "ª"="a",
  "±"="",
  "-"="",
  ""="",
  "_"="",
  "\\+"="",
  "\\."="",
  "\\,"=""
)

StrQuery <-paste0("SELECT \"id\", \"Token\", ROW_NUMBER () OVER (ORDER BY \"id\") FROM \"Ocorrencias2\" WHERE \"Tipo\"=1 ORDER BY \"id\"")
ocorrencias <- le_dados(StrQuery)
desconectar_db()
gc()

ocorrencias$Token <- str_replace_all(ocorrencias$Token,"[^[:graph:]]", " ")
gc()

ocorrencias$Token <- str_replace(ocorrencias$Token, "^([0123456789])", "n\\1")
gc()

ocorrencias$Token <- str_replace_all(ocorrencias$Token,StrReplace)
gc()

ocorrencias$Token <- tolower(ocorrencias$Token)
gc()

ocorrencias$Token <- rm_accent(ocorrencias$Token)
gc()

StrQuery <-paste0("SELECT \"IDSignificado\", \"Palavra\" FROM \"Dicionario\"")
dicionario <- le_dados(StrQuery)
desconectar_db()
gc()

dicionario$Palavra <- tolower(dicionario$Palavra)
dicionario$Palavra <- rm_accent(dicionario$Palavra)
gc()

id <- ocorrencias[, 1]
idsignificado <- dicionario[, 1]
token <- ocorrencias[, 2]
palavra <- dicionario[, 2]

comp <- token %in% palavra
gc()


startTime <- Sys.time()

for(i in 1:114712856){
  if(comp[i]){
    id_idsig <- palavra %in% token[i]
    id_idsig <- which(unlist(id_idsig))
    id_idsig <- id_idsig[1]
    StrQuery <- paste0("UPDATE \"Ocorrencias2\" SET \"IDSignificado\" = ", as.integer(idsignificado[id_idsig]),"  WHERE id = ", as.integer(id[i]),"")
    escreve_dados(StrQuery)
    print(StrQuery)
    print(paste0("Faltam: ", 114712856-i, " palavras"))
  }
}

desconectar_db()

endTime <- Sys.time()
diffTime <- endTime - startTime
diffTime