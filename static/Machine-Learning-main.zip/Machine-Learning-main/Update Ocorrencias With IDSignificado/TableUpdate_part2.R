startTime <- Sys.time()

for(i in 12821228:25518538){
  if(comp[i]){
    id_idsig <- palavra %in% token[i]
    id_idsig <- which(unlist(id_idsig))
    id_idsig <- id_idsig[1]
    StrQuery <- paste0("UPDATE \"Ocorrencias\" SET \"IDSignificado\" = ", as.integer(idsignificado[id_idsig]),"  WHERE id = ", as.integer(id[i]),"")
    escreve_dados(StrQuery)
    print(StrQuery)
    print(paste0("Faltam: ", 25518538-i, " palavras"))
  }
}

desconectar_db()

endTime <- Sys.time()
diffTime <- endTime - startTime
diffTime
