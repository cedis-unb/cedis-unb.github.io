import time
import spacy
import psycopg2

conn = psycopg2.connect(host="localhost",database="oasisbr",user="postgres",password="Omadheoc77")

nlp = spacy.load("pt_core_news_lg")
cur = conn.cursor()
curUpdt = conn.cursor()

limit = 244949
offset = 244949

sql1 = """SELECT * FROM "oasisbr2" WHERE abstract IS NOT NULL LIMIT %s OFFSET %s"""
cur.execute(sql1, (limit,offset))
row = cur.fetchone()
cont = 1
sql = """INSERT INTO "Palavras" ("idOasisBR","Palavra","Lemma","Ocorrencias","Fonte","Tipo")
             VALUES(%s,%s,%s,1,%s,%s) RETURNING id;"""

begin = time.time()
while row is not None:
	print("Abstract n. ", cont+offset)
	id = row[615]
    # tratamento do abstract
	doc = nlp(row[1329])
	for token in doc:
		if token.pos_ == "NOUN" or token.pos_ == "PROPN":
			curUpdt.execute(sql, (id,token.text,token.lemma_,1,1))
			vendor_id = curUpdt.fetchone()[0]
			conn.commit()
#		print(token.text, token.pos_, token.tag_, token.dep_)
	for ent in doc.ents:
		curUpdt.execute(sql, (id,ent.text,"",1,3))
		vendor_id = curUpdt.fetchone()[0]
		conn.commit()
#		print(ent.text, ent.start_char, ent.end_char, ent.label_)
    # tratamento do título
	doc = nlp(row[1211])
	for token in doc:
		if token.pos_ == "NOUN" or token.pos_ == "PROPN":
			curUpdt.execute(sql, (id,token.text,token.lemma_,2,1))
			vendor_id = curUpdt.fetchone()[0]
			conn.commit()
#		print(token.text, token.pos_, token.tag_, token.dep_)
	for ent in doc.ents:
		curUpdt.execute(sql, (id,ent.text,"",2,3))
		vendor_id = curUpdt.fetchone()[0]
		conn.commit()
#		print(ent.text, ent.start_char, ent.end_char, ent.label_)
	row = cur.fetchone()
	cont=cont+1

end = time.time()
  
# total time taken
print(f"Total runtime of the program is {end - begin}")

cur.close()
curUpdt.close()
conn.close()