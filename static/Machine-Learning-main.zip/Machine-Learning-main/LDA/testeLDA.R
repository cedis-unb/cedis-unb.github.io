library(C50)
library(janitor)
library(stringr)
library(stringi)
library(topicmodels)
library(quanteda)
library(readr)
library(wordcloud)

startTime <- Sys.time()
data00 <- read_csv("D:\\UnB\\DFCris\\ciencias_exatas_e_da_terra_matematica.csv")
data01 <- read_csv("D:\\UnB\\DFCris\\ciencias_biologicas_microbiologia.csv")

data00 <- rbind(data00, data01)

data0 <- data00[-3:-13]
data0 <- data0[-4:-9]
data0 <- data0[-2]

lim <- nrow(data0)

StrReplace = c(
  "/"="",
  "\""="",
  "\'"="",
  "c\\("="",
  "C\\("="",
  "\\("="",
  "\\)"="",
  "\\\\"="",
  "\\:"="",
  "~"="",
  ";"="",
  "\\^"="",
  "="="",
  ">"="",
  "<"="",
  "º"="o",
  "ª"="a",
  "±"="",
  "-"="",
  ""="",
  "_"="",
  "\\+"="",
  "\\."="",
  "\\,"="",
  "modelos" = "modelo",
  "clula" = "celula"
)
data1 <- data0[1:lim,]

for (l in 1:lim){
  data1[l,"abstract"] <- rm_accent(data1[l,"abstract"])
  data1[l,"abstract"] <- str_replace(data1[l,"abstract"], "^([0123456789])", "n\\1")
  data1[l,"abstract"] <- str_replace_all(data1[l,"abstract"],StrReplace)
  data1[l,"abstract"] <- tolower(data1[l,"abstract"])
  
}

set.seed(9850)
g <- runif(nrow(data1))
data1 <- data1[order(g), ]
rm(g)


part <- ceiling(lim * 0.75)
part1 <- ceiling(lim * 0.75)+1
dadosT <- data1[1:part,]
dadosV <- data1[part1:lim,]

corp = corpus(dadosT, docid_field = "id", text_field = "abstract", meta = list(), unique_docnames = FALSE)
corp

dfm = dfm(corp, remove_punct=T, remove=stopwords("pt")) ## como remover em ingles também??
dfm <- dfm_select(dfm, pattern = stopwords("en"), selection = "remove", case_insensitive = TRUE)
dfm <- dfm_select(dfm, pattern = blacklist, selection = "remove", case_insensitive = TRUE)
dfm <- dfm_select(dfm, pattern = blacklist2, selection = "remove", case_insensitive = TRUE)
dfm <- dfm_select(dfm, selection = "remove", case_insensitive = TRUE, min_nchar = 4)

dtm = convert(dfm, to = "topicmodels")

dtm

startTimeMod <- Sys.time()

set.seed(203)
m = LDA(dtm, method = "Gibbs", k =  50 , control = list(alpha = 0.8)) # (lim %/% 5)
m

terms(m, 10)

topic = 2
words = posterior(m)$terms[topic,]
topwords = head(sort(words, decreasing = T), n = 20)
topwords

wordcloud(names(topwords), topwords)

endTimeMod <- Sys.time()
diffTimeMod <- endTimeMod - startTimeMod
diffTimeMod

# visualização no browser!

library(LDAvis)

dtm = dtm[slam::row_sums(dtm) > 0, ]
phi = as.matrix(posterior(m)$terms)
theta <- as.matrix(posterior(m)$topics)
vocab <- colnames(phi)
doc.length = slam::row_sums(dtm)
term.freq = slam::col_sums(dtm)[match(vocab, colnames(dtm))]

json = createJSON(phi = phi, theta = theta, vocab = vocab,
                 doc.length = doc.length, term.frequency = term.freq)
serVis(json)


library(tidytext)

ap_topics <- tidy(m, matrix = "beta")
ap_topics

library(ggplot2)
library(dplyr)

ap_top_terms <- ap_topics %>%
  group_by(topic) %>%
  slice_max(beta, n = 20) %>% 
  ungroup() %>%
  arrange(topic, -beta)

ap_top_terms %>%
  mutate(term = reorder_within(term, beta, topic)) %>%
  ggplot(aes(beta, term, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free") +
  scale_y_reordered()

library(tidyr)

beta_wide <- ap_topics %>%
  mutate(topic = paste0("topic", topic)) %>%
  pivot_wider(names_from = topic, values_from = beta) %>%
  filter(topic1 > .001 | topic2 > .001) %>%
  mutate(log_ratio = log2(topic2 / topic1))

beta_wide

endTime <- Sys.time()

diffTimeTot <- endTime - startTime
diffTimeTot

ap_documents <- tidy(m, matrix = "gamma")
ap_documents

ap_documents_value <- as.numeric(as.double(ap_documents[,3]))

ap_top_terms2 <- ap_topics %>%
  group_by(topic) %>%
  slice_max(beta, n = 16) %>%
  ungroup() %>%
  arrange(topic, -beta)

ap_top_terms2

write.csv(ap_documents, "D:\\UnB\\DFCris\\ap_documents.csv", row.names = FALSE)
write.csv(ap_topics, "D:\\UnB\\DFCris\\ap_topics.csv", row.names = FALSE)

