library(h2o)
library(dplyr)

nHidden <- ceiling(sqrt(nDocs* length(lista_areas_teste)))

h2o.init(nthreads = -1)

ModeloNN <- h2o.deeplearning(y = 'Status', 
                             training_frame = as.h2o(dadosT),
                             hidden = c(nHidden, nHidden),
                             epochs = 1000)

prevNN <- h2o.predict(ModeloNN, newdata = as.h2o(dadosV %>% select(-Status)))
prevNN <- as.data.frame(prevNN)
dadosV["prevNN"] <- as.factor(prevNN$predict)

h2o.shutdown(prompt = FALSE)

rm(ModeloNN, prevNN)
