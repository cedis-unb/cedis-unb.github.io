#################################################################################
#  Autor: Sergio Antonio Andrade de Freitas (sergiofreitas@unb.br)
#  Data: 30/setembro/2022
#  Projeto: Previsao de area de pesquisa Capes para OasisBR
#
#  Arquivo: 0_Run.R
#  Descricao: 
#################################################################################

source("D:/Desenvolvimento/R/C50RandomForrest/DBaccess.R")
lista_areas_teste <- c(
  'c(\"BIODIVERSIDADE VEGETAL\", \"CIÊNCIAS BIOLÓGICAS\")',
  'c(\"BIOLOGIA MORFOFUNCIONAL\", \"CIÊNCIAS BIOLÓGICAS\")',
  'c(\"BIOECOLOGIA\", \"CIÊNCIAS BIOLÓGICAS\")',
  'c(\"BIOPROSPECÇÃO MOLECULAR\", \"CIÊNCIAS BIOLÓGICAS\")',
  'c(\"ECOLOGIA E RECURSOS NATURAIS\", \"CIÊNCIAS BIOLÓGICAS\")',
  'c(\"BIOQUIMICA\", \"CIÊNCIAS BIOLÓGICAS\")',
  'c(\"ECOLOGIA E CONSERVAÇÃO\", \"CIÊNCIAS BIOLÓGICAS\")',
  'c(\"BIOLOGIA CELULAR\", \"CIÊNCIAS BIOLÓGICAS\")',
  'c(\"ECOLOGIA\", \"CIÊNCIAS BIOLÓGICAS\")',
  'c(\"BIOLOGIA CELULAR E MOLECULAR\", \"CIÊNCIAS BIOLÓGICAS\")',
  'c(\"PROCESSOS E FENÔMENOS DA INDUSTRIA DE TRANSFORMAÇÃO\", \"ENGENHARIAS\")',
  'c(\"CONSTRUCAO\", \"ENGENHARIAS\")',
  'c(\"FOTOBIOMODULAÇÃO, BIOMARCADORES E SISTEMAS DIAGNÓSTICOS\", \"ENGENHARIAS\")',
  'c(\"PESQUISA OPERACIONAL E ENGENHARIA DE MANUFATURA\", \"ENGENHARIAS\")',
  'c(\"TECNOLOGIA MINERAL\", \"ENGENHARIAS\")',
  'c(\"ENGENHARIA ELÉTRICA\", \"ENGENHARIAS\")',
  'c(\"GEOTECNIA\", \"ENGENHARIAS\")',
  'c(\"ENGENHARIA QUÍMICA\", \"ENGENHARIAS\")',
  'c(\"GESTÃO DA PRODUÇÃO\", \"ENGENHARIAS\")',
  'c(\"ESTRUTURA, PROCESSAMENTO E PROPRIEDADES DE MATERIAIS\", \"ENGENHARIAS\")'
  )

startTime <- Sys.time()
source("D:/Desenvolvimento/R/C50RandomForrest/C50.v3.R")
source("D:/Desenvolvimento/R/C50RandomForrest/h2o.R")

library(caret)

result <- confusionMatrix(dadosV[, "prevC50"], dadosV[, 1], mode="prec_recall")
result

c50Results <- as.matrix(result, what = "classes")
c50Results.df <- as.data.frame(t(c50Results))
write.csv(c50Results.df,"C:/Users/renan/OneDrive/Área de Trabalho/Testes/c50Results.csv")
rm(c50Results, c50Results.df)

result <- confusionMatrix(dadosV[, "prevRF"], dadosV[, 1], mode="prec_recall")
result

rfResults <- as.matrix(result, what = "classes")
rfResults.df <- as.data.frame(t(rfResults))
write.csv(rfResults.df,"C:/Users/renan/OneDrive/Área de Trabalho/Testes/rfResults.csv")
rm(rfResults, rfResults.df)

result <- confusionMatrix(dadosV[, "prevNN"], dadosV[, 1], mode="prec_recall")
result

nnResults <- as.matrix(result, what = "classes")
nnResults.df <- as.data.frame(t(nnResults))
write.csv(nnResults.df,"C:/Users/renan/OneDrive/Área de Trabalho/Testes/nnResults.csv")
rm(nnResults, nnResults.df)

endTime <- Sys.time()
diffTime <- endTime - startTime
diffTime