#################################################################################
#  Autor: Sergio Ant?nio Andrade de Freitas (sergiofreitas@unb.br)
#  Data: 2/julho/2022
#  Projeto: Previs?o OasisBR
#
#  Descri??o: Faz a leitura e previs?o de campos para a base OasisBR
#################################################################################

library(C50)
library(randomForest)
library(janitor)

itemBase <- "idOasisBR"
itemApoio <- "IDSignificado"
ItemDestino <- "capesResearchGreatArea"

#############################################################################
##
## L? as entradas base (idOsisBR) do banco de dados e o item Destino a ser
##     na previs?o.
##  Observa??o: 
##     1. s?o selecionados apenas os resumos em Portugu?s (por OU PORTUGUES)
##     2. Para o treinamento s?o selecionados apenas entradas com itemBase n?o vazio
##
#############################################################################

#StrQuery <-
#  paste0(
#    "select \"id\" AS \"",itemBase,"\",\"",ItemDestino,"\" AS \"Status\", LENGTH(abstract) as \"TamResumo\" from \"OasisBR\" WHERE  (\"capesResearchGreatArea\" ='BIOFISICA' OR \"capesResearchGreatArea\" ='AGRICULTURA')"
#  )
StrQuery <-
  paste0(
    "select \"id\" AS \"",itemBase,"\",\"",ItemDestino,"\" AS \"Status\", LENGTH(abstract) as \"TamResumo\" from \"OasisBR\" WHERE  ("
  )

na <- length(lista_areas_teste)
i <- 1
for(a in lista_areas_teste){
  StrQuery <- paste0(StrQuery, "\"",ItemDestino,"\" = '",a,"'")
  if (i!= na) StrQuery <- paste0(StrQuery, " OR ")
  i<-i+1
}
StrQuery <- paste0(StrQuery,")")

#print(StrQuery)
dataset <- le_dados(StrQuery)
dataset$Status <- rm_accent(dataset$Status)
nDocs <- nrow(dataset)


listaBase  <- unique(dataset[, itemBase]) # lista de elementos Base ?nicos

ocorrencias.df <- c()
for (id in listaBase) {
  StrQuery <- paste0(
    "SELECT \"idOasisBR\", \"IDSignificado\",SUM(\"Ocorrencias\") AS \"Ocorrencias\" FROM \"Ocorrencias\" WHERE \"IDSignificado\" <> 0 AND \"idOasisBR\"=\'", id,"\' GROUP BY \"idOasisBR\",\"IDSignificado\""
  )
#  print(StrQuery)
  temp.df <- le_dados(StrQuery)
  
  ocorrencias.df <- rbind(ocorrencias.df, temp.df)
}



listaApoio <- unique(ocorrencias.df[, itemApoio])
DadosG <- data.frame(matrix(0,
                            nrow = length(listaBase),
                            ncol = length(listaApoio)))
rownames(DadosG) <- listaBase
colnames(DadosG) <- listaApoio

nDataset = nrow(ocorrencias.df)
for (l in 1:nDataset) {
  i <- as.character(ocorrencias.df[l, itemBase])
  j <- as.character(ocorrencias.df[l, itemApoio])
  Ocorrencias <- as.integer(ocorrencias.df[l, "Ocorrencias"])
  DadosG[i, j] <- Ocorrencias
}


listaStatus <- c()
for (l in listaBase) {
  listaStatus <- c(listaStatus, unique(dataset[dataset[, itemBase] == l, "Status"]))
}

DadosG <- cbind(listaStatus, DadosG)
names(DadosG)[1] <- "Status"
DadosG <- remove_empty(DadosG, which = c("cols"))
DadosG$Status <- factor(DadosG$Status)

part <- ceiling(nDocs * 0.75)
part1 <- ceiling(nDocs * 0.75)+1
dadosT <- DadosG[1:part,]
dadosV <- DadosG[part1:nDocs,]


ModeloC50 <- C5.0(x = dadosT[, -1], y = dadosT[,1], trials = 10)
ModeloRF <- randomForest(x = dadosT[, -1], y = dadosT[,1], trials = 10)

# Testa o modelo
dadosV["prevC50"] <- predict(ModeloC50, type = "class", newdata = dadosV)
dadosV["prevRF"] <- predict(ModeloRF, type = "class", newdata = dadosV)

rm(DadosG,dataset,ModeloC50,ModeloRF,ocorrencias.df,a,itemApoio,itemBase,ItemDestino,listaApoio,listaBase,listaStatus,na)
rm(part,part1)
rm(temp.df,id,i,j,l,nDataset,Ocorrencias,StrQuery)
