#Importar os pacotes
library("jsonlite") #Pacote para a manipulação do .json
library("pacman") # Pacote para a manipulação dos pacotes

#Abrir o arquivo json em um dataframe
fiocruzData <- stream_in(file("/home/renan/Documentos/fiocruz.json"))

#Ver o tipo, no caso apenas para verificar se é mesmo um dataframe
class(fiocruzData)

#Exibir o dataframe
fiocruzData #Também pode ser usado o View(fiocruzData) para exibir em uma tabela

#Limprar os pacotes
p_unload(all) #Limpa todos os pacotes add-ons (necessita do pacman)

#Lipar o Ambiente (Environment)
rm(list=ls())

#Limpar o console
cat("\014") #Ou Ctrl+L
