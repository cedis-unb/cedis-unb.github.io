#Importar os pacotes
library("rio") #Pacote para a manipulação do .csv
library("rpart")
library("rpart.plot")
library("pacman") # Pacote para a manipulação dos pacotes

#Abrir o arquivo json em um dataframe
fiocruz <- import("/home/renan/Desenvolvimento/R/fiocruzReduzido.csv")

delete <- c("V1")

fiocruz <- fiocruz[, !(names(fiocruz) %in% delete)]

rm(delete)

fiocruz$author.ordemAutoria <- as.factor(fiocruz$author.ordemAutoria)
fiocruz$keyword <- as.numeric(as.factor(fiocruz$keyword))
fiocruz$author.name <- as.numeric(as.factor(fiocruz$author.name))
fiocruz$author.citationName_1 <- as.numeric(as.factor(fiocruz$author.citationName_1))
fiocruz$author.citationName_2 <- as.numeric(as.factor(fiocruz$author.citationName_2))
fiocruz$author.citationName_3 <- as.numeric(as.factor(fiocruz$author.citationName_3))
fiocruz$author.citationName_4 <- as.numeric(as.factor(fiocruz$author.citationName_4))
fiocruz$author.citationName_5 <- as.numeric(as.factor(fiocruz$author.citationName_5))
fiocruz$author.identifierLattes <- as.numeric(as.factor(fiocruz$author.identifierLattes))
fiocruz$author.nationality <- as.numeric(as.factor(fiocruz$author.nationality))
fiocruz$author.birthCity <- as.numeric(as.factor(fiocruz$author.birthCity))
fiocruz$author.birthState <- as.numeric(as.factor(fiocruz$author.birthState))
fiocruz$author.birthCountry <- as.numeric(as.factor(fiocruz$author.birthCountry))
fiocruz$author.researchArea_1 <- as.numeric(as.factor(fiocruz$author.researchArea_1))
fiocruz$author.researchArea_2 <- as.numeric(as.factor(fiocruz$author.researchArea_2))
fiocruz$author.researchArea_3 <- as.numeric(as.factor(fiocruz$author.researchArea_3))
fiocruz$author.researchArea_4 <- as.numeric(as.factor(fiocruz$author.researchArea_4))
fiocruz$author.researchArea_5 <- as.numeric(as.factor(fiocruz$author.researchArea_5))
fiocruz$author.miniBiography <- as.numeric(as.factor(fiocruz$author.miniBiography))
fiocruz$author.miniBiography_eng <- as.numeric(as.factor(fiocruz$author.miniBiography_eng))
fiocruz$author.identifierOrcid <- as.numeric(as.factor(fiocruz$author.identifierOrcid))

str(fiocruz)


#Embaralhar o dataframe
set.seed(9850)
g <- runif(nrow(fiocruz))
fiocruz_random <- fiocruz[order(g),]

modelo1 <- rpart(author.ordemAutoria ~ ., data=fiocruz_random[1:200,], method="class")

rpart.plot(modelo1)
rpart.plot(modelo1, type=3, extra=101, fallen.leaves=T)

predicao1 <- predict(modelo1, fiocruz_random[201:256,], type="class")

table(fiocruz_random[201:256,5], predicted = predicao1)

#Limprar os pacotes
p_unload(all) #Limpa todos os pacotes add-ons (necessita do pacman)

#Lipar o Ambiente (Environment)
rm(list=ls())

#Limpar o console
cat("\014") #Ou Ctrl+L
