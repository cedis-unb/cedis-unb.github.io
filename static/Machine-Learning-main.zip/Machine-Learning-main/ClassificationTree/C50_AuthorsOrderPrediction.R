#Importar os pacotes necessárias
library("C50")
library("rio")
library("caret")

#Importar o arquivo .csv (lembrar de mudar o caminho do arquivo caso necessário)
fiocruz <- import("~/Desenvolvimento/R/ClassificationTree/fiocruz5PrimeirosAutores.csv")

#Formatar os campos do data frame
source("~/Desenvolvimento/R/ClassificationTree/FormatarCampos_AuthorsOrderPrediction.R")
tempoFormatarCampos <- endTime_formatCamposOrdemAutoria - startTime_formatCamposOrdemAutoria
tempoFormatarCampos
str(fiocruz)

table(fiocruz$authorOrdemAutoria)

#Embaralhar o dataframe
set.seed(3560)
g <- runif(nrow(fiocruz))
fiocruzRandom <- fiocruz[order(g),]

head(fiocruzRandom)

#Criar o modelo de treino
startTime_modeloC50 <- Sys.time()
modelo1 <- C5.0(fiocruzRandom[1:800000,-3], fiocruzRandom[1:800000,3])
endTime_modeloC50 <- Sys.time()
tempoTotal_modeloC50 <- endTime_modeloC50 - startTime_modeloC50 
tempoTotal_modeloC50
modelo1

#Gerar a predição
startTime_predictionC50 <- Sys.time()
prediction1 <- predict(modelo1, fiocruzRandom[800001:893708,])
endTime_predictionC50 <- Sys.time()
tempoTotal_predictionC50 <- endTime_predictionC50 - startTime_predictionC50
tempoTotal_predictionC50

#Matriz de Confusão
table(fiocruzRandom[800001:893708,3], predicted = prediction1)

#Matriz de Confusão e Acurácia
confusionMatrix(prediction1, fiocruzRandom[800001:893708,3])

#Limpar os pacotes, o environment e o console
source("~/Desenvolvimento/R/ClassificationTree/CleanUp.R")
