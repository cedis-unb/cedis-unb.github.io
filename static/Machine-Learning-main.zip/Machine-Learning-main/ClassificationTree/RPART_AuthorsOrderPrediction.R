#Importar os pacotes necessárias
library("rpart")
library("rpart.plot")
library("rio")
library("caret")

#Importar o arquivo .csv (lembrar de mudar o caminho do arquivo caso necessário)
fiocruz <- import("~/Desenvolvimento/R/ClassificationTree/fiocruz5PrimeirosAutores.csv")

#Formatar os campos do data frame
source("~/Desenvolvimento/R/ClassificationTree/FormatarCampos_AuthorsOrderPrediction.R")
str(fiocruzRandom)

table(fiocruz$authorOrdemAutoria)

#Embaralhar o dataframe
set.seed(3560)
g <- runif(nrow(fiocruz))
fiocruzRandom <- fiocruz[order(g),]

head(fiocruz)

#Criar o modelo de treino
startTime_modeloRpart <- Sys.time()
modelo2 <- rpart(authorOrdemAutoria ~ ., data=fiocruzRandom[1:800000,], method="class")
endTime_modeloRpart <- Sys.time()
tempoTotal_modeloRpart <- endTime_modeloRpart - startTime_modeloRpart
tempoTotal_modeloRpart

rpart.plot(modelo2, box.palette="Blues")

#Gerar a predição
startTime_predictionRpart <- Sys.time()
prediction2 <- predict(modelo2, fiocruzRandom[800001:893708,], type="class")
endTime_predictionRpart <- Sys.time()
tempoTotal_predictionRpart <- endTime_predictionRpart - startTime_predictionRpart
tempoTotal_predictionRpart

#Matriz de Confusão
table(fiocruzRandom[800001:893708,3], predicted = prediction2)

#Matriz de Confusão e Acurácia
confusionMatrix(prediction2, fiocruzRandom[800001:893708,3])

#Limpar os pacotes, o environment e o console
source("~/Desenvolvimento/R/ClassificationTree/CleanUp.R")
