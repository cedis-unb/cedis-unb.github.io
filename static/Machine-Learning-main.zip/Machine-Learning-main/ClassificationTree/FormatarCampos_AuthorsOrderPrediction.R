startTime_formatCamposOrdemAutoria <- Sys.time() #Tempo de iníco da formatação

#Deletar do data frame as colunas que não são necessárias para a predição
delete <- c("V1", "authorMiniBiography", "authorMiniBiography_eng")
fiocruz <- fiocruz[, !(names(fiocruz) %in% delete)]
rm(delete)

#Formatar os campos restantes no data frame
fiocruz$keyword <- as.numeric(as.factor(fiocruz$keyword))
fiocruz$authorName <- as.numeric(as.factor(fiocruz$authorName))
fiocruz$authorOrdemAutoria <- as.factor(fiocruz$authorOrdemAutoria)
fiocruz$authorCitationName_1 <- as.numeric(as.factor(fiocruz$authorCitationName_1))
fiocruz$authorCitationName_2 <- as.numeric(as.factor(fiocruz$authorCitationName_2))
fiocruz$authorCitationName_3 <- as.numeric(as.factor(fiocruz$authorCitationName_3))
fiocruz$authorCitationName_4 <- as.numeric(as.factor(fiocruz$authorCitationName_4))
fiocruz$authorCitationName_5 <- as.numeric(as.factor(fiocruz$authorCitationName_5))
fiocruz$authorIdentifierLattes <- as.numeric(as.factor(fiocruz$authorIdentifierLattes))
fiocruz$authorNationality <- as.numeric(as.factor(fiocruz$authorNationality))
fiocruz$authorBirthCity <- as.numeric(as.factor(fiocruz$authorBirthCity))
fiocruz$authorBirthState <- as.numeric(as.factor(fiocruz$authorBirthState))
fiocruz$authorBirthCountry <- as.numeric(as.factor(fiocruz$authorBirthCountry))
fiocruz$authorResearchArea_1 <- as.numeric(as.factor(fiocruz$authorResearchArea_1))
fiocruz$authorResearchArea_2 <- as.numeric(as.factor(fiocruz$authorResearchArea_2))
fiocruz$authorResearchArea_3 <- as.numeric(as.factor(fiocruz$authorResearchArea_3))
fiocruz$authorResearchArea_4 <- as.numeric(as.factor(fiocruz$authorResearchArea_4))
fiocruz$authorResearchArea_5 <- as.numeric(as.factor(fiocruz$authorResearchArea_5))
fiocruz$authorIdentifierOrcid <- as.numeric(as.factor(fiocruz$authorIdentifierOrcid))

endTime_formatCamposOrdemAutoria <- Sys.time()
