#Importar o gestor de pacotes
library("pacman")

#Limprar os pacotes
p_unload(all) #Limpa todos os pacotes add-ons (necessita do pacman)

#Lipar o Ambiente (Environment)
rm(list=ls())

#Limpar o console
cat("\014") #Ou Ctrl+L
