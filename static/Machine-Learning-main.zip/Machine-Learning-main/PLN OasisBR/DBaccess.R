### 
# Centraliza o acesso ao banco de dados
# Retorna sempre o dataframe "dados" a partir da strQuery
###
library(RPostgres)

le_dados = function(strQuery) {
  db <- 'oasisbr'  #provide the name of your db
  host_db <- 'localhost'
  db_port <- '5432'  # or any other port specified by the DBA
  db_user <- 'postgres'
  db_password <- 'SENHA'
  con <-
    dbConnect(
      RPostgres::Postgres(),
      dbname = db,
      host = host_db,
      port = db_port,
      user = db_user,
      password = db_password
    )
  dados <- dbGetQuery(con, strQuery)
  
  #embaralhas as linhas
  set.seed(9850)
  g <- runif(nrow(dados))
  dados <- dados[order(g), ]
  rm(g)
  
  # VERIFICAR NECESSIDADE
  dados <- replace(x = dados,
                   list = is.na(dados),
                   values = 0)
  
  dbDisconnect(con)
  rm(con, db, db_password, db_port, db_user, host_db, strQuery)
  return(dados)
}


escreve_dados = function(strQuery) {
  db <- 'oasisbr'  #provide the name of your db
  host_db <- 'localhost'
  db_port <- '5432'  # or any other port specified by the DBA
  db_user <- 'postgres'
  db_password <- 'SENHA'
  con <-
    dbConnect(
      RPostgres::Postgres(),
      dbname = db,
      host = host_db,
      port = db_port,
      user = db_user,
      password = db_password
    )
  dados <- dbExecute(con, strQuery)
  
  dbDisconnect(con)
  rm(con, db, db_password, db_port, db_user, host_db, strQuery)
}

rm_accent <- function(str,pattern="all") {
  if(!is.character(str))
    str <- as.character(str)
  pattern <- unique(pattern)
  if(any(pattern=="Ç"))
    pattern[pattern=="Ç"] <- "ç"
  symbols <- c(
    acute = "áéíóúÁÉÍÓÚýÝ",
    grave = "àèìòùÀÈÌÒÙ",
    circunflex = "âêîôûÂÊÎÔÛ",
    tilde = "ãõÃÕñÑ",
    umlaut = "äëïöüÄËÏÖÜÿ",
    cedil = "çÇ"
  )
  nudeSymbols <- c(
    acute = "aeiouAEIOUyY",
    grave = "aeiouAEIOU",
    circunflex = "aeiouAEIOU",
    tilde = "aoAOnN",
    umlaut = "aeiouAEIOUy",
    cedil = "cC"
  )
  accentTypes <- c("Ž","`","^","~","š","ç")
  if(any(c("all","al","a","todos","t","to","tod","todo")%in%pattern)) # opcao retirar todos
    return(chartr(paste(symbols, collapse=""), paste(nudeSymbols, collapse=""), str))
  for(i in which(accentTypes%in%pattern))
    str <- chartr(symbols[i],nudeSymbols[i], str)
  return(str)
}
