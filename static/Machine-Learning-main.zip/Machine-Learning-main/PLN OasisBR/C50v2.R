#################################################################################
#  Autor: Sergio Antônio Andrade de Freitas (sergiofreitas@unb.br)
#  Data: 2/julho/2022
#  Projeto: Previsão OasisBR
#
#  Descrição: Faz a leitura e previsão de campos para a base OasisBR
#################################################################################
startTime <- Sys.time()

library(C50)
library(janitor)
library(stringr)
library(stringi)

#library(dplyr)
#library(rio)
#library(caret)

itemBase <- "idOasisBR"
itemApoio <- "Token"
ItemDestino <- "capesResearchGreatArea"
offset <- 0     # linha inicial no banco de dados
limit <- 10   # quantidade de linhas a ser lidas no banco de dados

#############################################################################
##
## Lê as entradas base (idOsisBR) do banco de dados e o item Destino a ser
##     na previsão.
##  Observação: 
##     1. são selecionados apenas os resumos em Português (por OU PORTUGUES)
##     2. Para o treinamento são selecionados apenas entradas com itemBase não vazio
##
#############################################################################

StrQuery <-
  paste0(
    "SELECT \"id\" AS \"",itemBase,"\",\"",ItemDestino,"\" AS \"Status\", LENGTH(abstract) as \"TamResumo\"
        FROM \"OasisBR\"
        WHERE (lang=\'por\' OR lang=\'PORTUGUES\') AND \"",ItemDestino,"\" <> \'NULL\'
         AND NOT \"",ItemDestino,"\" LIKE 'c(\"%'
        LIMIT ",limit," OFFSET ", offset
  )
#print(StrQuery)
dataset <- le_dados(StrQuery)
#dataset$Status <- rm_accent(dataset$Status)

listaBase  <- unique(dataset[, itemBase]) # lista de elementos Base únicos

#############################################################################
##
## Para cada entrada idOasisBR fala a leitura das respectivas ocorrências
##    dos Tokens:
##    Fontes: 1 - abstract, 2 - título, 3 - keywords, 4 - outros
##    Tipos: 1 - palavras simples, 
##           2 - palavra composta,
##           3 - entidades,
##           4 - lematização da palavra simples (tipo 1)
##
#############################################################################
fonte <- 2
tipo  <- 1
tamMinResumo <- 100  # tamanho minimo de caracteres para ser considerado um resumo válido
tamMinToken <- 4     # tamanho mínimo de caracteres de um Token
StrReplace = c(
  "/"="",
  "\'"="",
  "\""="",
  "c\\("="",
  "C\\("="",
  "\\("="",
  "\\)"="",
  "\\\\"="",
  "\\:"="",
  "~"="",
  ";"="",
  "\\^"="",
  "="="",
  ">"="",
  "<"="",
  "º"="o",
  "ª"="a",
  "±"="",
  "-"="",
  ""="",
  "_"="",
  "\\+"="",
  "\\."="",
  "\\,"=""
)

ocorrencias.df <- c()
for (id in listaBase) {
  if(fonte == 1 && dataset[dataset[,itemBase]==id,"TamResumo"] < tamMinResumo) {
    next
  }
  StrQuery <- paste0(
    "SELECT \"idOasisBR\", \"Token\",\"Ocorrencias\" FROM \"Ocorrencias\" WHERE \"Tipo\"=",tipo," AND \"Fonte\"=",fonte," AND \"idOasisBR\"=\'", id,"\'"
  )
  #  print(StrQuery)
  temp.df <- le_dados(StrQuery)
  
  temp.df$Token <- rm_accent(temp.df$Token)  #remove os acentos
  temp.df$Token <- stri_enc_toascii(temp.df$Token)
  
  # limpa os caracteres especiais do Token
  temp.df[,'Token'] <- str_replace(temp.df[,'Token'], "^([0123456789])", "n\\1")
  temp.df[,'Token'] <- str_replace_all(temp.df[,'Token'],StrReplace)
  temp.df[,'Token'] <- tolower(temp.df[,'Token'])
  
  # apaga as linhas com um tamanho de Token menor que o mínimo
  temp.df <- subset(temp.df, nchar(Token) >= tamMinToken) 
  
  ocorrencias.df <- rbind(ocorrencias.df, temp.df)
}


listaApoio <- unique(ocorrencias.df[, itemApoio])
DadosG <- data.frame(matrix(0,
                            nrow = length(listaBase),
                            ncol = length(listaApoio)))
rownames(DadosG) <- listaBase
colnames(DadosG) <- listaApoio

nDataset = nrow(ocorrencias.df)
for (l in 1:nDataset) {
  i <- as.character(ocorrencias.df[l, itemBase])
  j <- as.character(ocorrencias.df[l, itemApoio])
  Ocorrencias <- as.integer(ocorrencias.df[l, "Ocorrencias"])
  DadosG[i, j] <- Ocorrencias
}


listaStatus <- c()
for (l in listaBase) {
  listaStatus <- c(listaStatus, unique(dataset[dataset[, itemBase] == l, "Status"]))
}

DadosG <- cbind(listaStatus, DadosG)
names(DadosG)[1] <- "Status"
DadosG <- remove_empty(DadosG, which = c("cols"))
DadosG$Status <- factor(DadosG$Status)

part <- ceiling(limit * 0.75)
part1 <- ceiling(limit * 0.75)+1
dadosT <- DadosG[1:part,]
dadosV <- DadosG[part1:limit,]

#options(expressions=100000)
#myFormula <-
#  as.formula(paste("Status", paste(names(dadosT)[-c(1)], collapse = " + "), sep = " ~ "))
#Modelo <- C5.0(myFormula, data = dadosT, trials = 10)

Modelo <- C5.0(x = dadosT[, listaApoio], y = dadosT$Status, trials = 10)


# Testa o modelo
dadosV["prev"] <- predict(Modelo, type = "class", newdata = dadosV)
predTable <- table(dadosV[, 1], predicted = dadosV[, "prev"])
Precision <- prop.table(predTable, margin = 2)[2, 2]
Recall    <- prop.table(predTable, margin = 1)[2, 2]
F1 <- 2 * (Precision * Recall) / (Precision + Recall)

F1
Recall
Precision

endTime <- Sys.time()
diffTime <- endTime - startTime
diffTime
rm(temp.df,id,i,j,l,nDataset,Ocorrencias,StrQuery)