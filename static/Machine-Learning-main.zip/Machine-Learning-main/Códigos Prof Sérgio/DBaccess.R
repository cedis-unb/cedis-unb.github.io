#################################################################################
#  Autor: Sergio Ant�nio Andrade de Freitas (sergiofreitas@unb.br)
#  Data: 17/agosto/2021
#  Projeto: Previs�o de reten��o
#
#  Arquivo: DBaccess.R
#  Descri��o: Fun��es para leitura e escrita em banco de dados
#  Direitos Reservados
#################################################################################

### 
# Centraliza o acesso ao banco de dados
# Retorna sempre o dataframe "dados" a partir da strQuery
###
library(RPostgres)
#library(DBI)

le_dados = function(strQuery) {
  db <- 'SAGA'  #provide the name of your db
  host_db <- 'localhost'
  db_port <- '5432'  # or any other port specified by the DBA
  db_user <- 'postgres'
  db_password <- 'SENHA'
  con <-
    dbConnect(
      RPostgres::Postgres(),
      dbname = db,
      host = host_db,
      port = db_port,
      user = db_user,
      password = db_password
    )
  dados <- dbGetQuery(con, strQuery)
  
  #embaralhas as linhas
  set.seed(9850)
  g <- runif(nrow(dados))
  dados <- dados[order(g), ]
  rm(g)
  
  # VERIFICAR NECESSIDADE
  dados <- replace(x = dados,
                   list = is.na(dados),
                   values = 0)
  
  dbDisconnect(con)
  rm(con, db, db_password, db_port, db_user, host_db, strQuery)
  return(dados)
}

le_dados2 = function(strQuery) {
  db <- 'SAGA'  #provide the name of your db
  host_db <- 'localhost'
  db_port <- '5432'  # or any other port specified by the DBA
  db_user <- 'postgres'
  db_password <- 'SENHA'
  con <-
    dbConnect(
      RPostgres::Postgres(),
      dbname = db,
      host = host_db,
      port = db_port,
      user = db_user,
      password = db_password
    )
  dados <- dbGetQuery(con, strQuery)
  
  dbDisconnect(con)
  rm(con, db, db_password, db_port, db_user, host_db, strQuery)
  
  #embaralhas as linhas
  set.seed(9850)
  g <- runif(nrow(dados))
  dados <- dados[order(g), ]
  rm(g)
  
  # transforma o n�mero do Status em string (formado, ativo ou evadido)
  dados <-    transform(dados, "Status" = ifelse(Status == 1, "formado", Status))
  dados <-    transform(dados, "Status" = ifelse(Status == 2, "ativo", Status))
  dados <-    transform(dados, "Status" = ifelse(Status == 5, "evadido", Status))
#  dados[dados$Status == 1]$Status <- "formado"
#  dados[dados$Status == 2]$Status <- "ativo"
#  dados[dados$Status == 5]$Status <- "evadido"
  
  
  dados[sapply(dados, is.character)] <-
    lapply(dados[sapply(dados, is.character)], as.factor)
#  dados$Permanencia <- as.factor(dados$Permanencia)
  
  
  # Remove colunas desnecess�rias para o APriori. N�o � necess�rio para os outros algoritmos.
  #excluir <- c("idtransation", IDEstudante", "Ingresso", "Curso", "Status", "Permanencia","UltMov", "Tempo")
  excluir <-
    c("idtransation",
#      "IDEstudante",
      "Permanencia",
      "Ingresso",
      "Curso",
      "UltMov",
      "Tempo")
#  dados <- dados[, !(names(dados) %in% excluir)]
  dados <- replace(x = dados,
                   list = is.na(dados),
                   values = 0)
  
  
  rm(excluir)
  
  return(dados)
}


escreve_dados = function(strQuery) {
  db <- 'SAGA'  #provide the name of your db
  host_db <- 'localhost'
  db_port <- '5432'  # or any other port specified by the DBA
  db_user <- 'postgres'
  db_password <- 'SENHA'
  con <-
    dbConnect(
      RPostgres::Postgres(),
      dbname = db,
      host = host_db,
      port = db_port,
      user = db_user,
      password = db_password
    )
  dados <- dbExecute(con, strQuery)
  
  dbDisconnect(con)
  rm(con, db, db_password, db_port, db_user, host_db, strQuery)
}