#################################################################################
#  Autor: Sergio Ant�nio Andrade de Freitas (sergiofreitas@unb.br)
#  Data: 17/agosto/2021
#  Projeto: Previs�o de reten��o
#
#  Arquivo: 0_Run.R
#  Descri��o: Executa o pacote R
#  Direitos Reservados
#################################################################################


######### �ltimo usado, com indicador da for�a da previs�o da evas�o.
source("DBaccess.R")
Cursos <- c("automotiva","aeroespacial","software","energia","eletr�nica")
source("Treinar.C50_por_turma.v5.R")
############