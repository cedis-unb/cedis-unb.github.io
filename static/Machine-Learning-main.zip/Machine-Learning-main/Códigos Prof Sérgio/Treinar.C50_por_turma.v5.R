#################################################################################
#  Autor: Sergio Ant�nio Andrade de Freitas (sergiofreitas@unb.br)
#  Data: 17/agosto/2021
#  Projeto: Previs�o de reten��o
#
#  Arquivo: Treinar C50.R
#  Descri��o: Executa o treinamento e previs�o usando o algoritmo C50
#  Direitos Reservados
#################################################################################

library(C50)
library(janitor)

F1_corte <- 0.5
Semestres = c("2015/2",
              "2016/1",
              "2016/2",
              "2017/1",
              "2017/2",
              "2018/1",
              "2018/2",
              "2019/1"
)
# Zera a previs�o de evas�o no banco de dados
escreve_dados(paste0("UPDATE \"Estudantes\" SET \"PrevEvasao\"=0"))
escreve_dados(paste0("UPDATE \"Estudantes\" SET \"iPrevEvasao\"=0"))
itemBase <- "IDEstudante"
itemApoio <- "IDDisciplina"
TotTotal_evadidos <- 0

for(ingresso in Semestres) {
  for (c in Cursos) {
    cat(paste0(c, " Modelo treinado com a turma ", ingresso, "\n"))
    #TREINAMENTO DO MODELO
    #considerando s� o curso
    dataset <-
      le_dados(
        paste0(
          "SELECT \"Abrev\",\"IDDisciplina\"
        FROM \"Matriculas\",\"Turmas\",\"Estudantes\",\"Fluxos\",\"Cursos\"
        WHERE \"Matriculas\".\"IDTurma\"=\"Turmas\".\"IDTurma\" AND \"Estudantes\".\"IDEstudante\"=\"Matriculas\".\"IDEstudante\" AND \"Fluxos\".\"IDFluxo\"=\"Estudantes\".\"IDFluxo\" AND \"Cursos\".\"IDCurso\"=\"Fluxos\".\"IDCurso\"
        AND \"Abrev\"=UPPER(\'",
          c,
          "\')"
        )
      )
    #considerando toda a FGA
#    dataset <-
#      le_dados(
#        paste0(
#          "SELECT \"Abrev\",\"IDDisciplina\"
#        FROM \"Matriculas\",\"Turmas\",\"Estudantes\",\"Fluxos\",\"Cursos\"
#        WHERE \"Matriculas\".\"IDTurma\"=\"Turmas\".\"IDTurma\" AND \"Estudantes\".\"IDEstudante\"=\"Matriculas\".\"IDEstudante\" AND \"Fluxos\".\"IDFluxo\"=\"Estudantes\".\"IDFluxo\" AND \"Cursos\".\"IDCurso\"=\"Fluxos\".\"IDCurso\"
#        AND \"UACurso\"=\'FGA\'"
#        )
#      )
    
    listaApoio <- unique(dataset[, itemApoio])
    
    dataset <-
      le_dados(
        paste0(
          "SELECT \"Abrev\",\"Status\",COUNT(\"Matriculas\".\"IDEstudante\") AS \"Matriculas\",\"Ingresso.Periodo\" AS \"Ingresso\",\"IDDisciplina\", \"Matriculas\".\"IDEstudante\" AS \"IDEstudante\"
        FROM \"Matriculas\",\"Turmas\",\"Estudantes\",\"Fluxos\",\"Cursos\"
        WHERE \"Matriculas\".\"IDTurma\"=\"Turmas\".\"IDTurma\" AND \"Estudantes\".\"IDEstudante\"=\"Matriculas\".\"IDEstudante\" AND \"Fluxos\".\"IDFluxo\"=\"Estudantes\".\"IDFluxo\" AND \"Cursos\".\"IDCurso\"=\"Fluxos\".\"IDCurso\"
        AND \"Abrev\"=UPPER(\'",
          c,
          "\') AND \"Ingresso.Periodo\"=\'",
          ingresso,
          "\' GROUP BY \"Abrev\", \"Status\", \"Matriculas\".\"IDEstudante\", \"Ingresso.Periodo\",\"IDDisciplina\""
        )
      )
    
    listaBase  <- unique(dataset[, itemBase])
    
    dadosT <- data.frame(matrix(0,
                                nrow = length(listaBase),
                                ncol = length(listaApoio)))
    rownames(dadosT) <- listaBase
    colnames(dadosT) <- listaApoio
    
    nDataset = nrow(dataset)
    for (l in 1:nDataset) {
      i <- as.character(dataset[l, itemBase])
      j <- as.character(dataset[l, itemApoio])
      Tentativas <- as.integer(dataset[l, "Matriculas"])
      dadosT[i, j] <- Tentativas
    }
    
    listaStatus <- c()
    for (l in listaBase) {
      listaStatus <- c(listaStatus, unique(dataset[dataset[, itemBase] == l, "Status"]))
    }
    
    
    dadosT <- cbind(listaStatus, dadosT)
    names(dadosT)[1] <- "Status"
    dadosT <- remove_empty(dadosT, which = c("cols"))
    dadosT$Status <- factor(dadosT$Status)

    myFormula <-
      as.formula(paste("Status", paste(names(dadosT)[-c(1)], collapse = " + "), sep =
                         " ~ "))
    Modelo <- C5.0(myFormula, data = dadosT, trials = 10)
    
    
    Semestres_escolhidos <- c()
    for (ingresso2 in Semestres) {
      # TESTE DO MODELO EM OUTROS SEMESTRES
      dataset <-
        le_dados(
          paste0(
            "SELECT \"Abrev\",\"Status\",COUNT(\"Matriculas\".\"IDEstudante\") AS \"Matriculas\",\"Ingresso.Periodo\" AS \"Ingresso\",\"IDDisciplina\", \"Matriculas\".\"IDEstudante\" AS \"IDEstudante\"
        FROM \"Matriculas\",\"Turmas\",\"Estudantes\",\"Fluxos\",\"Cursos\"
        WHERE \"Matriculas\".\"IDTurma\"=\"Turmas\".\"IDTurma\" AND \"Estudantes\".\"IDEstudante\"=\"Matriculas\".\"IDEstudante\" AND \"Fluxos\".\"IDFluxo\"=\"Estudantes\".\"IDFluxo\" AND \"Cursos\".\"IDCurso\"=\"Fluxos\".\"IDCurso\"
        AND \"Abrev\"=UPPER(\'",
            c,
            "\') AND \"Ingresso.Periodo\"=\'",
            ingresso2,
            "\' GROUP BY \"Abrev\", \"Status\", \"Matriculas\".\"IDEstudante\", \"Ingresso.Periodo\",\"IDDisciplina\""
          )
        )
      
      listaBase  <- unique(dataset[, itemBase])
      
      dadosV <- data.frame(matrix(0,
                                  nrow = length(listaBase),
                                  ncol = length(listaApoio)))
      rownames(dadosV) <- listaBase
      colnames(dadosV) <- listaApoio
      
      nDataset = nrow(dataset)
      for (l in 1:nDataset) {
        i <- as.character(dataset[l, itemBase])
        j <- as.character(dataset[l, itemApoio])
        Tentativas <- as.integer(dataset[l, "Matriculas"])
        dadosV[i, j] <- Tentativas
      }
      
      ## O PROBLEMA EST� AQUI, basta usar a linha que j� tem o n�mero de matr�cula
      
      listaStatus <- c()
      for (l in listaBase) {
        listaStatus <- c(listaStatus, unique(dataset[dataset[, itemBase] == l, "Status"]))
      }
      
      dadosV <- cbind(listaStatus, dadosV)
      names(dadosV)[1] <- "Status"
      dadosV <- remove_empty(dadosV, which = c("cols"))
      dadosV$Status <- factor(dadosV$Status)
      
      dadosV["prev"] <-
        predict(Modelo, type = "class", newdata = dadosV)
      
      
      predTable  <- table(dadosV[, 1], predicted = dadosV[, "prev"])
      Precision <- prop.table(predTable, margin = 2)[2, 2]
      Recall <- prop.table(predTable, margin = 1)[2, 2]
      if (!is.nan(Precision) && !is.nan(Recall)) {
        F1 <- 2 * (Precision * Recall) / (Precision + Recall)
        if (F1 > F1_corte && !is.nan(F1)) {
          Semestres_escolhidos <- c(ingresso2, Semestres_escolhidos)
        }
      } else {
        F1 <- NaN
      }
      
      cat(
        paste0(
          c,
          " (",
          ingresso2,
          "), Estudantes=",
          nrow(dadosV),
          " Evadidos=",
          nrow(dadosV[dadosV[, "prev"] == 5, ]),
          " F1=",
          F1,
          "\n"
        )
      )
    }
    
    
    Total_evadidos <- 0
    for (ingresso2 in Semestres_escolhidos) {
      # TESTE DO MODELO EM OUTROS SEMESTRES
      rm(dadosV,dataset)
      
      dataset <-
        le_dados(
          paste0(
            "SELECT \"Abrev\",\"Status\",COUNT(\"Matriculas\".\"IDEstudante\") AS \"Matriculas\",\"Ingresso.Periodo\" AS \"Ingresso\",\"IDDisciplina\", \"Matriculas\".\"IDEstudante\" AS \"IDEstudante\"
        FROM \"Matriculas\",\"Turmas\",\"Estudantes\",\"Fluxos\",\"Cursos\"
        WHERE \"Matriculas\".\"IDTurma\"=\"Turmas\".\"IDTurma\" AND \"Estudantes\".\"IDEstudante\"=\"Matriculas\".\"IDEstudante\" AND \"Fluxos\".\"IDFluxo\"=\"Estudantes\".\"IDFluxo\" AND \"Cursos\".\"IDCurso\"=\"Fluxos\".\"IDCurso\"
        AND \"Status\"=2 AND \"Abrev\"=UPPER(\'",
            c,
            "\') AND \"Ingresso.Periodo\"=\'",
            ingresso2,
            "\' GROUP BY \"Abrev\", \"Status\", \"Matriculas\".\"IDEstudante\", \"Ingresso.Periodo\",\"IDDisciplina\""
          )
        )
      
      listaBase  <- unique(dataset[, itemBase])
      
      dadosV <- data.frame(matrix(0,
                                  nrow = length(listaBase),
                                  ncol = length(listaApoio)))
      rownames(dadosV) <- listaBase
      colnames(dadosV) <- listaApoio
      
      nDataset = nrow(dataset)
      for (l in 1:nDataset) {
        i <- as.character(dataset[l, itemBase])
        j <- as.character(dataset[l, itemApoio])
        Tentativas <- as.integer(dataset[l, "Matriculas"])
        dadosV[i, j] <- Tentativas
      }
      
      listaStatus <- c()
      for (l in listaBase) {
        listaStatus <- c(listaStatus, unique(dataset[dataset[, itemBase] == l, "Status"]))
      }
      
      dadosV <- cbind(listaStatus, dadosV)
      names(dadosV)[1] <- "Status"
      dadosV <- remove_empty(dadosV, which = c("cols"))
      dadosV$Status <- factor(dadosV$Status)
      
      
      #    excluir <- c("idtransation", "Permanencia","Ingresso","Curso","UltMov","Tempo")
      #    dadosV <- dadosV[, !(names(dadosV) %in% excluir)]
      dadosV["prev"] <-
        predict(Modelo, type = "class", newdata = dadosV)
      
      nEvadidos <- nrow(dadosV[dadosV[, "prev"] == 5,])
      cat(
        paste0(
          "PREVIS�O 2021/2 -> ",
          c,
          " (",
          ingresso2,
          "), Estudantes=",
          nrow(dadosV),
          " Evadidos=",
          nEvadidos,
          "\n"
        )
      )
      
      Total_evadidos <-
        Total_evadidos + nEvadidos
      if (nEvadidos > 0) {
        listEstudantesEvadidos <- rownames(dadosV[dadosV[, "prev"] == 5, ])
        for (l in listEstudantesEvadidos) {
          escreve_dados(
            paste0(
              "UPDATE \"Estudantes\" SET \"iPrevEvasao\"=\"iPrevEvasao\" + 1 WHERE \"IDEstudante\" =",
              l
            )
          )
        }
#        cat(paste0("Evadidos: ", dadosV[dadosV[, "prev"] == 5, "IDEstudante"], "\n"))
      }
      
    }
    cat(paste0(
      "Total de evadidos previstos (",
      c,
      ") = ",
      Total_evadidos,
      "\n\n"
    ))
    TotTotal_evadidos <- TotTotal_evadidos + Total_evadidos
    
  }
  cat("Total geral de evadidos previstos = ", TotTotal_evadidos, "\n")
}
escreve_dados(
  paste0(
    "UPDATE \"Estudantes\" SET \"PrevEvasao\"=1 WHERE \"iPrevEvasao\"<>0"
  )
)

rm(Modelo, c,
   F1,
   i,
   nEvadidos,
   Precision,
   predTable)
rm(Recall,
   Semestres,
   Total_evadidos,
   ingresso2,
   myFormula,
   TotTotal_evadidos,
   dataset, nDataset, dadosT,dadosV
)
rm(listEstudantesEvadidos, ingresso,F1_corte,itemApoio,itemBase,j,l,listaApoio,listaBase,listaStatus,Semestres_escolhidos, Tentativas)
