source("D:/UnB/DFCris/generate_models/gera_modelos.R")

range = read.csv2("D:/UnB/DFCris/generate_models/csv/Range.csv", sep = ",")
mindocs = read.csv2("D:/UnB/DFCris/generate_models/csv/MinDocs.csv",  sep = ",")

