source("Config.R")
source("funcoes.R")

gera_modelo_a = function(Tipo, Subtipo, min_docs, ini_intervalo, fim_intervalo){
	startTime <- Sys.time()
	
	if(Tipo == "RF"){
		if(Subtipo == "trad"){
			Modelo <- gera_modelo(dados.df,"RF","trad")
			save(Modelo, file=paste0(PastaModelo, "Modelo.RF.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".RData"))
		} else {
			Modelo <- gera_modelo(dados.df,"RF","ranger")
			save(Modelo, file=paste0(PastaModelo, "Modelo.RF.ranger.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".RData"))
		}
	}
	if(Tipo == "C50"){
		Modelo <- gera_modelo(dados.df,"C50")
		save(Modelo, file=paste0(PastaModelo, "Modelo.C50.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".RData"))
	}
	if(Tipo == "NN"){
		Modelo <- gera_modelo(dados.df,"NN")
		save(Modelo, file=paste0(PastaModelo, "Modelo.NN.h2o.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".RData"))
	}
	
	Sys.time() - startTime
}

gera_modelo_b = function(Tipo, Subtipo, min_docs, ini_intervalo, fim_intervalo, itemDestino){
	startTime <- Sys.time()
	
	## Elimina as colunas desnecess?rias
	itens <- itens[! itens %in% c(itemDestino)]
	for(i in itens){
		dados.df[i] <- c()
	}

	colnames(dados.df)[colnames(dados.df) == itemDestino] <- "Status"
	dados.df <- subset(dados.df, Status != 0)

	if(Tipo == "RF"){
		if(Subtipo == "trad"){
			Modelo <- gera_modelo(dados.df,"RF","trad")
			save(Modelo, file=paste0(PastaModelo, "Modelo.RF.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".RData"))
		} else {
			Modelo <- gera_modelo(dados.df,"RF","ranger")
			save(Modelo, file=paste0(PastaModelo, "Modelo.RF.ranger.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".RData"))
		}
	}
	if(Tipo == "C50"){
		Modelo <- gera_modelo(dados.df,"C50")
		save(Modelo, file=paste0(PastaModelo, "Modelo.C50.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".RData"))
	}
	if(Tipo == "RPART"){
		Modelo <- gera_modelo(dados.df,"RPART")
		save(Modelo, file=paste0(PastaModelo, "Modelo.Rpart.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".RData"))
	}
	if(Tipo == "NN"){
		Modelo <- gera_modelo(dados.df,"NN")
		save(Modelo, file=paste0(PastaModelo, "Modelo.NN.h2o.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".RData"))
	}
	
	Sys.time() - startTime
}

gera_modelo_c = function(Tipo, Subtipo, min_docs, ini_intervalo, fim_intervalo, itemDestino){
	startTime <- Sys.time()
	
	All_GreatAreaSA <- c(
		"CIENCIAS AGRARIAS",
		"CIENCIAS BIOLOGICAS",
		"CIENCIAS DA SAUDE",
		"CIENCIAS EXATAS E DA TERRA",
		"CIENCIAS HUMANAS",
		"CIENCIAS SOCIAIS APLICADAS",
		"ENGENHARIAS",
		"LINGUISTICA, LETRAS E ARTES",
		"MULTIDISCIPLINAR"
	)


	for(area in All_GreatAreaSA) {
		print(paste0("Gerando modelo para a ?rea: ", area))
		dados.area <- dados.df[dados.df$GreatAreaSA==area,]
  
		## Elimina as colunas desnecess?rias
		itens <- itens[! itens %in% c(itemDestino)]
		for(i in itens){
			dados.area[i] <- c()
		}
  
		colnames(dados.area)[colnames(dados.area) == itemDestino] <- "Status"
		dados.area <- subset(dados.area, Status != 0)
  
		if(Tipo == "RF"){
			if(Subtipo == "trad"){
				Modelo <- gera_modelo(dados.area,"RF","trad")
				save(Modelo, file=paste0(PastaModelo, "Modelo.RF.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".",area,".RData"))
			} else {
				Modelo <- gera_modelo(dados.area,"RF","ranger")
				save(Modelo, file=paste0(PastaModelo, "Modelo.RF.ranger.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".",area,".RData"))
			}
		}
		if(Tipo == "C50"){
			Modelo <- gera_modelo(dados.area,"C50")
			save(Modelo, file=paste0(PastaModelo, "Modelo.C50.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".",area,".RData"))
		}
		if(Tipo == "RPART"){
			Modelo <- gera_modelo(dados.area,"RPART")
			save(Modelo, file=paste0(PastaModelo, "Modelo.Rpart.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".",area,".RData"))
		}
		if(Tipo == "NN"){
			Modelo <- gera_modelo(dados.df,"NN")
			save(Modelo, file=paste0(PastaModelo, "Modelo.NN.h2o.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".",area,".RData"))
		}
	}

	Sys.time() - startTime
}

gera_modelo_d = function(Tipo, Subtipo, min_docs, ini_intervalo, fim_intervalo, itemDestino){
	startTime <- Sys.time()
	
	colnames(dados.df)[colnames(dados.df) == itemDestino] <- "Status"
	dados.df <- subset(dados.df, Status != 0)

	if(Tipo == "RF"){
		if(Subtipo == "trad"){
		Modelo <- gera_modelo(dados.df,"RF","trad")
		save(Modelo, file=paste0(PastaModelo, "Modelo.RF.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".RData"))
		} else {
			Modelo <- gera_modelo(dados.df,"RF","ranger")
			save(Modelo, file=paste0(PastaModelo, "Modelo.RF.ranger.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".RData"))
		}
	}
	if(Tipo == "C50"){
		Modelo <- gera_modelo(dados.df,"C50")
		save(Modelo, file=paste0(PastaModelo, "Modelo.C50.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".RData"))
	}
	if(Tipo == "RPART"){
		Modelo <- gera_modelo(dados.df,"RPART")
		save(Modelo, file=paste0(PastaModelo, "Modelo.Rpart.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".RData"))
	}
	if(Tipo == "NN"){
		Modelo <- gera_modelo(dados.df,"NN")
		save(Modelo, file=paste0(PastaModelo, "Modelo.NN.h2o.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".RData"))
	}

	Sys.time() - startTime
}

gera_modelo_e = function(Tipo, Subtipo, min_docs, ini_intervalo, fim_intervalo, itemDestino){
	startTime <- Sys.time()
	
	All_GreatAreaSA <- c(
	  "CIENCIAS AGRARIAS",
	  "CIENCIAS BIOLOGICAS",
	  "CIENCIAS DA SAUDE",
	  "CIENCIAS EXATAS E DA TERRA",
	  "CIENCIAS HUMANAS",
	  "CIENCIAS SOCIAIS APLICADAS",
	  "ENGENHARIAS",
	  "LINGUISTICA, LETRAS E ARTES",
	  "MULTIDISCIPLINAR"
	)


	for(area in All_GreatAreaSA) {
	  load(paste0(PastaDF, "df.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",area,".e.Rdata"))
	  
	  
	  print(paste0("Gerando modelo para a ?rea: ", area))
	  dados.area <- dados.df
	   
	  colnames(dados.area)[colnames(dados.area) == itemDestino] <- "Status"
	  dados.area <- subset(dados.area, Status != 0)
	  
	  
	  if(Tipo == "RF"){
		if(Subtipo == "trad"){
		  Modelo <- gera_modelo(dados.area,"RF","trad")
		  save(Modelo, file=paste0(PastaModelo, "Modelo.RF.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".",area,".e.RData"))
		} else {
		  Modelo <- gera_modelo(dados.area,"RF","ranger")
		  save(Modelo, file=paste0(PastaModelo, "Modelo.RF.ranger.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".",area,".e.RData"))
		}
	  }
	  if(Tipo == "C50"){
		Modelo <- gera_modelo(dados.area,"C50")
		save(Modelo, file=paste0(PastaModelo, "Modelo.C50.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".",area,".e.RData"))
	  }
	  if(Tipo == "RPART"){
		Modelo <- gera_modelo(dados.area,"RPART")
		save(Modelo, file=paste0(PastaModelo, "Modelo.Rpart.trad.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".",area,".e.RData"))
	  }
	  if(Tipo == "NN"){
		Modelo <- gera_modelo(dados.df,"NN")
		save(Modelo, file=paste0(PastaModelo, "Modelo.NN.h2o.",min_docs,"x",ini_intervalo,"x",fim_intervalo,".",TBLocorrencias,".",itemDestino,".",area,".RData"))
	  }
	}

	Sys.time() - startTime
}